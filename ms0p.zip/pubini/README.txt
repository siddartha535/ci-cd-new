PubIni
------

This program is intended to run as a service alongside its owning 
queue manager, and publish the contents of ini files to a topic. It
also shows the current environment variables as they may be useful in 
understanding queue manager behaviour.

Configuration
-------------
On the Distributed platforms, you can set up Services which are 
automatically started as the queue manager starts.

A suggested configuration is 
  DEFINE SERVICE(PubIni)
   CONTROL(QMGR)
   SERVTYPE(SERVER)
   STARTCMD(<path>\pubini.cmd)
   STARTARG(-m +QMNAME+ -d +MQ_DATA_PATH+ -d +MQ_Q_MGR_DATA_PATH+)              
   STOPCMD(+MQ_INSTALL_PATH+bin/amqsstop) 
   STOPARG(-m +QMNAME+ -p +MQ_SERVER_PID+)                              
   STDOUT(<path>\pubini.out)
   STDERR(<path>\pubini.err)

On Windows, use STOPCMD(taskkill) with  
STOPARGS(/t /pid +MQ_SERVER_PID /f). That will kill both the
batch program and the Java program it initiates.

The command path and output paths are probably going to be different for
your systems. 

It is important that the queue manager name be given as the first 
parameter (second token) in the STARTARG attribute. This is to help 
establish the correct environment when you have more than one MQ installation
on your system. 

You may need to edit the startup batch program or shell script to modify paths, 
depending on where you have installed the MQ code. 
   
The STARTARG attribute sets these parameters to the command. The queue
manager name is mandatory, along with at least one directory name.
           
Usage: pubini [-h] -m qmgr -d directory [-f file ] [-t topic]
Options:
 -h : Show this help message
 -m : Queue Manager 
 -d : Directory containing ini files          [Can be repeated]
 -t : Topic for publication of information    [Default SYSTEM.ADMIN.INI]
 -i : Republish interval in seconds           [Default 900 - 30 minutes]

All the named directories are searched for ini files containing full stanzas.
Each stanza is added to the output messages. Empty ini files, or those that 
do not contains full stanza-format information, are not published.

Setting the interval to 0 causes the program to run once and then exit. This
might be preferred by users who do not want to have a long-running, mostly-dormant
Java program running; they can handle retries and scheduling in the invoking
script.
 
Output Format
-------------
The collected data is published on a nominated topic to which any application
can subscribe. The publication consists of a single message containing the 
contents of the ini files. It is an XML-style message which looks like
    <PubIni Time="Dec 02 2013 18:00:00",QueueManager="QM1">
      <File Name="C:\mqm\Qmgrs\V80_W\qm.ini">
        <Stanza Name="ExitPath">
          <Attribute Name="ExitsDefaultPath" Value="c:\mqm\exits"/>
          <Attribute Name="ExitsDefaultPath64" Value="c:\mqm\exits64"/>
          ...
        </Stanza>
        <Stanza>
        ....
        </Stanza>
      </File>
      <File ...>
      </File>
      <Environment>
      <Attribute Name="PATH" Value="c:\windows"/>
      ...
      </Environment>
    </PubIni>
where the fields are filled in with the collected values. This should make it 
easy to parse.

The publication is made using 
the RETAIN option, so new subscribers can read the information without needing 
to wait for a new publication. It is also republished at intervals, in case
any of the files have changed.

Notes
-----
1. Because this command is intended to run as a service, and needs to read
   local files it only uses local bindings; there is no support for client 
   connections to remote queue managers.
2. Program is compiled and built against MQ V8 and Java 7; that will be 
   the mininum runtime level.
3. The environment variables for the service program may not be identical
   to those for the queue manager that started the program - the queue manager
   sets and resets some variables when it starts services.    
         